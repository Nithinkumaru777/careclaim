import { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import { fetchApi } from '../lib/api';
import { supabase } from '../lib/supabase';
import { fetchEventSource } from '@microsoft/fetch-event-source';
import { AgentTerminal } from '../components/AgentTerminal';
import type { TerminalEvent } from '../components/AgentTerminal';
import { PayoutWaterfall } from '../components/PayoutWaterfall';
import { StatusStamp } from '../components/StatusStamp';
import { formatCurrency } from '../lib/format';
import { toast } from 'sonner';
import { motion } from 'motion/react';

export function ClaimView() {
  const { id } = useParams();
  const [claim, setClaim] = useState<any>(null);
  const [events, setEvents] = useState<TerminalEvent[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (id) loadClaim();
  }, [id]);

  const loadClaim = async () => {
    try {
      const data = await fetchApi(`/api/claims/${id}`);
      setClaim(data);
      if (data.ai_reasoning_log) {
        setEvents(data.ai_reasoning_log);
      }
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const runAdjudication = async () => {
    if (!claim || claim.status !== 'PENDING') return;
    
    setIsProcessing(true);
    setEvents([]);
    
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;

    try {
      await fetchEventSource(`${import.meta.env.VITE_API_BASE_URL}/api/claims/${id}/process`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        onmessage(ev) {
          const data = JSON.parse(ev.data);
          if (ev.event === 'result') {
            setClaim(data);
            setIsProcessing(false);
          } else if (ev.event === 'error') {
            toast.error(data.message);
            setIsProcessing(false);
            loadClaim();
          } else {
            setEvents(prev => [...prev, { ts: Date.now(), event: ev.event as any, data }]);
          }
        },
        onerror(err) {
          toast.error('Connection lost');
          setIsProcessing(false);
          throw err;
        },
        onclose() {
          setIsProcessing(false);
        }
      });
    } catch (err) {
      console.error(err);
      setIsProcessing(false);
    }
  };

  if (!claim) return <div className="p-10 text-center font-mono">Loading...</div>;

  return (
    <div className="min-h-screen p-6 md:p-10 max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Left: Bill Details */}
      <div className="lg:col-span-3 space-y-6">
        <div className="bg-paper p-6 rounded-lg border border-rule">
          <h2 className="font-mono text-xs uppercase tracking-widest text-ink-soft border-b border-rule pb-2 mb-4">Claim Intake</h2>
          <div className="space-y-4 text-sm">
            <div>
              <div className="text-ink-soft">Patient ID</div>
              <div className="font-medium">{claim.patient_id}</div>
            </div>
            <div>
              <div className="text-ink-soft">Policy</div>
              <div className="font-mono bg-bone px-1 rounded inline-block">{claim.policies?.policy_number}</div>
            </div>
            <div>
              <div className="text-ink-soft">Diagnosis</div>
              <div className="font-mono bg-bone px-1 rounded inline-block">{claim.diagnosis_code}</div>
            </div>
            <div className="border-t border-rule pt-4">
              <div className="text-ink-soft mb-2">Itemized Bill</div>
              <div className="space-y-2">
                {claim.raw_bill_data.map((item: any, i: number) => (
                  <div key={i} className="flex justify-between font-mono text-xs p-2 bg-bone rounded">
                    <span className="truncate pr-2">{item.item_name} (x{item.quantity})</span>
                    <span>{formatCurrency(item.cost * item.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-mono font-bold mt-4 pt-2 border-t border-rule/50">
                <span>Total</span>
                <span>{formatCurrency(claim.total_billed)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Center: Agent Terminal */}
      <div className="lg:col-span-5 space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-serif text-pine-deep">AI Adjudication Core</h2>
          {claim.status === 'PENDING' && (
            <button 
              onClick={runAdjudication}
              disabled={isProcessing}
              className="bg-phosphor hover:bg-phosphor/80 text-pine-deep font-bold font-mono text-xs uppercase tracking-widest px-4 py-2 rounded transition-colors disabled:opacity-50 flex items-center gap-2 shadow-[0_0_15px_rgba(92,255,157,0.3)]"
            >
              {isProcessing ? 'Processing...' : 'Run Autonomous Adjudication'}
            </button>
          )}
        </div>
        
        <AgentTerminal events={events} isProcessing={isProcessing} />
      </div>

      {/* Right: Summary */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-paper p-6 rounded-lg border border-rule h-full shadow-sm flex flex-col">
          <div className="flex justify-between items-start border-b border-rule pb-4 mb-6">
            <h2 className="font-mono text-xs uppercase tracking-widest text-ink-soft">Decision Summary</h2>
            <StatusStamp status={claim.status} />
          </div>

          <div className="text-center mb-8">
            <div className="text-ink-soft text-sm mb-1">Approved Payout</div>
            <div className="font-serif text-5xl text-pine-deep tracking-tight">
              {formatCurrency(claim.approved_amount)}
            </div>
          </div>

          <div className="flex-1">
            {claim.payout_breakdown && (
              <PayoutWaterfall breakdown={claim.payout_breakdown} />
            )}
            
            {claim.payout_breakdown?.status === 'DENIED' && (
              <div className="mt-8 p-4 bg-vermilion/10 text-vermilion rounded border border-vermilion/20 text-sm">
                <div className="font-bold mb-1">Claim Denied</div>
                {claim.ai_reasoning_log?.filter((e: any) => e.data?.message?.includes('DENIED')).map((e: any, i: number) => (
                  <div key={i}>{e.data.message}</div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
