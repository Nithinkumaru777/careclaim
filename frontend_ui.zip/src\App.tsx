import { Routes, Route, Navigate } from 'react-router';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { NewClaim } from './pages/NewClaim';
import { ClaimView } from './pages/ClaimView';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/claims/new" element={<NewClaim />} />
      <Route path="/claims/:id" element={<ClaimView />} />
    </Routes>
  );
}
